Details of the addressbook resources in this directory:
All are exported as 3.0:

1.txt: simple vCard

2.txt: vCard created with Mulberry

3.txt: company vCard

4.txt: vCard with note

5.txt: vCard with all default fields filled in

6.txt: vCard with image   
    
7.txt: company vCard with image

8.txt: high ASCII content vCard

9.txt: double byte content vCard

10.txt: vCard with all custom fields filled in